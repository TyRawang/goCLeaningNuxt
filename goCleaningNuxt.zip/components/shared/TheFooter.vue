<template>
  <section>
    <div id="footer-menu" class="container">
      <div>
        <h3>About</h3>
        <p>Go Cleaning is a company based in Calgary that provides cleaning services. Our
          mission is to give the best customer satisfaction while empowering our cleaners.
        </p>
      </div>
      <div>
        <h3>Go Cleaning Menu</h3>
        <a href="#">Home</a>
        <a href="#">Services</a>
        <span><a href="#">Residential</a></span>
        <span><a href="#">Commercial</a></span>
        <span><a href="#">Airbnb</a></span>
        <a href="#">Testimonials</a>
        <a href="#">Faq</a>
        <a href="#">Blog</a>
        <a href="#">Contact</a>
      </div>
      <div>
        <h3>Recent Posts</h3>
        <a href="#">- Where Do We Start Cleaning?</a>
        <a href="#">- What Is Your Cleaning Style?</a>
        <a href="#">- Clean House, Cleaner Perspective</a>
      </div>
    </div>

    <footer>
      <p>© Copyright 2020 | All Rights Reserved | Sitemap | Powered by WebDesign Calgary</p>
    </footer>
  </section>
</template>
